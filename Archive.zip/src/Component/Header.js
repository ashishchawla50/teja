import React from "react";

function Header(props) {
  return (
    <>
      <div className="Header">
        <div className="pageInfo">Feedback</div>
        <div className="AccountInfo">
          Hi{" "}
          <a
            onClick={() => {
              javaScript: void 0;
            }}
          >
            {" "}
            Teja{" "}
          </a>
        </div>
      </div>
    </>
  );
}

export default Header;
