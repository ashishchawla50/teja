import React from "react";
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";

function Table(props) {
  const [startDate, setStartDate] = React.useState(new Date());
  return (
    <>
      <div className="Table">
        <div className="TableInner">
          <div className="TableControls">
            <DatePicker
              selected={startDate}
              onChange={(date) => setStartDate(date)}
            />
            <div className="SearchBox">
              <input type={"text"} placeholder="Search By File Name" />
              <button>Search</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Table;
