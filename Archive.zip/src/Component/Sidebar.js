import React from "react";

function Sidebar(props) {
  return (
    <>
      <div className="sideBar">
        <ul className="sideBarMenu">
          <li>Daashboard</li>
          <li>Feedback</li>
        </ul>
      </div>
    </>
  );
}

export default Sidebar;
